# Informazioni utili e comandi per avviare ed utilizzare il progetto

App: http://localhost:8080  
Endpoint utili:
- `GET /health` → stato applicazione  
- `GET /users` → lista utenti  
- `POST /users` con JSON `{ "name": "Tizio" }` → crea utente

# Tutti i comandi devono essere effttuati tramite terminale bash

## Avvio e costruzione container
```bash
docker compose up -d --build
```

## Test rapidi
```bash
curl http://localhost:8080/health
curl http://localhost:8080/users
curl -X POST http://localhost:8080/users -H "Content-Type: application/json" -d '{"name":"Carla"}'
```

## Log
```bash
docker compose logs -f db
docker compose logs -f app
```

## Stop Container
```bash
docker compose down
```

## Cancella i dati!
```bash
docker compose down -v
```
