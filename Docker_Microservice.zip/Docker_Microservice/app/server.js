import express from "express";
import pkg from "pg";
import path from "path";
import { fileURLToPath } from "url";

const { Pool } = pkg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 8080;
const DATABASE_URL =
  process.env.DATABASE_URL || "postgres://user:password@db:5432/mydb";

const pool = new Pool({ connectionString: DATABASE_URL });

const app = express();
app.use(express.json());

// file statici dalla cartella dell'app
app.use(express.static(__dirname));

// home: serve index.html
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// healthcheck
app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

// lista utenti
app.get("/users", async (req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT id, name FROM users ORDER BY id ASC"
    );
    res.json(rows);
  } catch (err) {
    console.error("DB error:", err.message);
    res.status(500).json({ error: "database_error" });
  }
});

// crea utente
app.post("/users", async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) {
      return res.status(400).json({ error: "missing_name" });
    }

    const { rows } = await pool.query(
      "INSERT INTO users(name) VALUES($1) RETURNING id, name",
      [name]
    );

    res.status(201).json(rows[0]);
  } catch (err) {
    console.error("DB error:", err.message);
    res.status(500).json({ error: "database_error" });
  }
});

app.listen(PORT, () => {
  console.log(`✅ App in esecuzione su http://localhost:${PORT}`);
});
