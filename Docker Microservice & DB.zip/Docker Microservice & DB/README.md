# Docker Junior Project (PostgreSQL + Node.js/Express)

## Avvio
```bash
docker compose up -d --build
```

App: http://localhost:8080  
Endpoint utili:
- `GET /health` → stato applicazione  
- `GET /users` → lista utenti  
- `POST /users` con JSON `{ "name": "Tizio" }` → crea utente

## Test rapidi
```bash
curl http://localhost:8080/health
curl http://localhost:8080/users
curl -X POST http://localhost:8080/users -H "Content-Type: application/json" -d '{"name":"Carla"}'
```

## Log
```bash
docker compose logs -f db
docker compose logs -f app
```

## Stop
```bash
docker compose down
```

## Reset totale (cancella i dati!)
```bash
docker compose down -v
```
